import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='jgunir',
    application_name='todo-list-serverless',
    app_uid='CmjyKCnspQv4Hnjc0M',
    org_uid='cce42d40-e361-458a-a453-6b6bed17e9c9',
    deployment_uid='c5b676b7-512a-4c22-8277-f052b9bda916',
    service_name='serverless-rest-api-with-dynamodb',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='3.8.4',
    disable_frameworks_instrumentation=False
)
handler_wrapper_kwargs = {'function_name': 'serverless-rest-api-with-dynamodb-dev-create', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/create.create')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
